# AR Physics App Unity Launcher
# This script helps launch Unity with the AR Physics project

Write-Host "🚀 AR Physics Explorer - Unity Launcher" -ForegroundColor Cyan
Write-Host "==========================================" -ForegroundColor Cyan
Write-Host ""

# Check if Unity Hub is installed
$unityHubPaths = @(
    "${env:ProgramFiles}\Unity Hub\Unity Hub.exe",
    "${env:ProgramFiles(x86)}\Unity Hub\Unity Hub.exe",
    "${env:LOCALAPPDATA}\Programs\Unity Hub\Unity Hub.exe"
)

$unityHubPath = $null
foreach ($path in $unityHubPaths) {
    if (Test-Path $path) {
        $unityHubPath = $path
        break
    }
}

# Check for direct Unity installation
$unityPaths = @(
    "${env:ProgramFiles}\Unity\Hub\Editor\*\Editor\Unity.exe",
    "${env:ProgramFiles(x86)}\Unity\Hub\Editor\*\Editor\Unity.exe"
)

$unityExe = $null
foreach ($pattern in $unityPaths) {
    $foundPaths = Get-ChildItem -Path $pattern -ErrorAction SilentlyContinue | Sort-Object LastWriteTime -Descending
    if ($foundPaths) {
        $unityExe = $foundPaths[0].FullName
        break
    }
}

$projectPath = "C:\Users\HP\ARPhysicsApp"

Write-Host "🔍 Checking Unity installation..." -ForegroundColor Yellow

if ($unityHubPath) {
    Write-Host "✅ Unity Hub found at: $unityHubPath" -ForegroundColor Green
    
    Write-Host ""
    Write-Host "📝 Setup Instructions:" -ForegroundColor Cyan
    Write-Host "1. Unity Hub will open" -ForegroundColor White
    Write-Host "2. Click 'Add' and select folder: $projectPath" -ForegroundColor White
    Write-Host "3. Make sure Unity 2021.3 LTS or later is installed" -ForegroundColor White
    Write-Host "4. Open the AR Physics project" -ForegroundColor White
    Write-Host ""
    
    Write-Host "🎯 Next Steps After Opening:" -ForegroundColor Cyan
    Write-Host "• Install AR Foundation packages (Window → Package Manager)" -ForegroundColor White
    Write-Host "• Configure build settings for Android/iOS" -ForegroundColor White
    Write-Host "• Set up XR Plug-in Management" -ForegroundColor White
    Write-Host ""
    
    Read-Host "Press Enter to launch Unity Hub..."
    Start-Process -FilePath $unityHubPath
    
} elseif ($unityExe) {
    Write-Host "✅ Unity Editor found at: $unityExe" -ForegroundColor Green
    
    Write-Host ""
    Write-Host "🚀 Launching Unity directly with project..." -ForegroundColor Yellow
    Write-Host ""
    
    Start-Process -FilePath $unityExe -ArgumentList "-projectPath `"$projectPath`""
    
} else {
    Write-Host "❌ Unity not found!" -ForegroundColor Red
    Write-Host ""
    Write-Host "📥 Please download and install Unity:" -ForegroundColor Yellow
    Write-Host "1. Download Unity Hub from: https://unity.com/download" -ForegroundColor White
    Write-Host "2. Install Unity 2021.3 LTS or later" -ForegroundColor White
    Write-Host "3. Run this script again" -ForegroundColor White
    Write-Host ""
    
    $response = Read-Host "Would you like to open the Unity download page? (y/n)"
    if ($response -eq 'y' -or $response -eq 'Y') {
        Start-Process "https://unity.com/download"
    }
}

Write-Host ""
Write-Host "📋 Project Information:" -ForegroundColor Cyan
Write-Host "• Project Path: $projectPath" -ForegroundColor White
Write-Host "• Main Scene: Assets/Scenes/ARPhysicsScene.unity" -ForegroundColor White
Write-Host "• Scripts Location: Assets/Scripts/" -ForegroundColor White
Write-Host ""
Write-Host "🎓 Physics Modules Included:" -ForegroundColor Cyan
Write-Host "• ⚡ Ohm's Law (V = IR)" -ForegroundColor White
Write-Host "• 🚀 Kinematic Motion (v = u + at)" -ForegroundColor White  
Write-Host "• 💪 Force and Motion (F = ma)" -ForegroundColor White
Write-Host ""
Write-Host "📖 For detailed instructions, see README.md" -ForegroundColor Yellow