# Unity AR Physics App Helper Script
param([string]$Action = "check")

function Show-Header {
    Write-Host "🎯 AR Physics Explorer - Unity Helper" -ForegroundColor Cyan
    Write-Host "====================================" -ForegroundColor Cyan
    Write-Host ""
}

function Check-UnityInstallation {
    Write-Host "🔍 Checking Unity installation status..." -ForegroundColor Yellow
    Write-Host ""
    
    # Check Unity Hub
    $hubPaths = @(
        "${env:ProgramFiles}\Unity Hub\Unity Hub.exe",
        "${env:ProgramFiles(x86)}\Unity Hub\Unity Hub.exe",
        "${env:LOCALAPPDATA}\Programs\Unity Hub\Unity Hub.exe"
    )
    
    $hubFound = $false
    foreach($path in $hubPaths) {
        if(Test-Path $path) {
            Write-Host "✅ Unity Hub: INSTALLED" -ForegroundColor Green
            Write-Host "   Location: $path" -ForegroundColor Gray
            $hubFound = $true
            break
        }
    }
    
    if(-not $hubFound) {
        Write-Host "❌ Unity Hub: NOT FOUND" -ForegroundColor Red
        return
    }
    
    # Check Unity Editor
    $editorPaths = Get-ChildItem -Path "${env:ProgramFiles}\Unity\Hub\Editor\*\Editor\Unity.exe" -ErrorAction SilentlyContinue
    
    if($editorPaths) {
        Write-Host "✅ Unity Editor: INSTALLED" -ForegroundColor Green
        foreach($editor in $editorPaths) {
            $version = ($editor.Directory.Parent.Name)
            Write-Host "   Version: $version" -ForegroundColor Gray
        }
        return $true
    } else {
        Write-Host "⚠️ Unity Editor: NOT INSTALLED" -ForegroundColor Yellow
        Write-Host "   Please install Unity 2021.3 LTS through Unity Hub" -ForegroundColor Gray
        return $false
    }
}

function Show-ProjectInfo {
    Write-Host "📁 AR Physics Project Information:" -ForegroundColor Cyan
    Write-Host ""
    Write-Host "Project Path:" -ForegroundColor White
    Write-Host "   C:\Users\HP\ARPhysicsApp" -ForegroundColor Green
    Write-Host ""
    Write-Host "Project Contents:" -ForegroundColor White
    Get-ChildItem -Path "." -Name | ForEach-Object {
        Write-Host "   ✅ $_" -ForegroundColor Green
    }
    Write-Host ""
}

function Launch-UnityHub {
    Write-Host "🚀 Launching Unity Hub..." -ForegroundColor Yellow
    $hubPath = "C:\Program Files\Unity Hub\Unity Hub.exe"
    if(Test-Path $hubPath) {
        Start-Process -FilePath $hubPath
        Write-Host "✅ Unity Hub launched successfully!" -ForegroundColor Green
    } else {
        Write-Host "❌ Cannot find Unity Hub" -ForegroundColor Red
    }
}

function Show-NextSteps {
    param([bool]$EditorInstalled)
    
    Write-Host "📝 Next Steps:" -ForegroundColor Cyan
    Write-Host ""
    
    if(-not $EditorInstalled) {
        Write-Host "1️⃣ Install Unity Editor:" -ForegroundColor Yellow
        Write-Host "   • In Unity Hub, go to 'Installs' tab" -ForegroundColor White
        Write-Host "   • Click 'Install Editor'" -ForegroundColor White
        Write-Host "   • Choose 'Unity 2021.3 LTS' (recommended for AR)" -ForegroundColor White
        Write-Host "   • Click 'Install' and wait for completion" -ForegroundColor White
        Write-Host ""
    }
    
    Write-Host "2️⃣ Add AR Physics Project:" -ForegroundColor Yellow
    Write-Host "   • In Unity Hub, go to 'Projects' tab" -ForegroundColor White
    Write-Host "   • Click 'Add' button" -ForegroundColor White
    Write-Host "   • Browse to: C:\Users\HP\ARPhysicsApp" -ForegroundColor Green
    Write-Host "   • Select the folder and click 'Add Project'" -ForegroundColor White
    Write-Host ""
    
    Write-Host "3️⃣ Open the Project:" -ForegroundColor Yellow
    Write-Host "   • Click on 'AR Physics Explorer' in the project list" -ForegroundColor White
    Write-Host "   • Unity Editor will open (first time takes a few minutes)" -ForegroundColor White
    Write-Host ""
    
    Write-Host "4️⃣ Install AR Packages (Once Unity Opens):" -ForegroundColor Yellow
    Write-Host "   • Window → Package Manager" -ForegroundColor White
    Write-Host "   • Change dropdown to 'Unity Registry'" -ForegroundColor White
    Write-Host "   • Install: AR Foundation, ARCore XR Plugin, ARKit XR Plugin" -ForegroundColor White
    Write-Host ""
    
    Write-Host "5️⃣ Test the App:" -ForegroundColor Yellow
    Write-Host "   • Open Assets/Scenes/ARPhysicsScene.unity" -ForegroundColor White
    Write-Host "   • Click Play button to test scripts" -ForegroundColor White
    Write-Host "   • Build for mobile device for full AR experience" -ForegroundColor White
    Write-Host ""
}

function Show-PhysicsModules {
    Write-Host "🎓 Physics Modules Ready:" -ForegroundColor Cyan
    Write-Host ""
    Write-Host "⚡ Ohm's Law Module (V = IR):" -ForegroundColor Yellow
    Write-Host "   • Interactive circuit simulation" -ForegroundColor White
    Write-Host "   • Real-time voltage, current, resistance calculations" -ForegroundColor White
    Write-Host "   • Visual effects: wire glow, electron flow, heating" -ForegroundColor White
    Write-Host ""
    Write-Host "🚀 Kinematic Module (v = u + at):" -ForegroundColor Yellow
    Write-Host "   • Projectile motion simulator" -ForegroundColor White
    Write-Host "   • Adjustable velocity, angle, acceleration" -ForegroundColor White
    Write-Host "   • Visual trajectory prediction and particle trails" -ForegroundColor White
    Write-Host ""
    Write-Host "💪 Force Module (F = ma):" -ForegroundColor Yellow
    Write-Host "   • Newton's second law demonstration" -ForegroundColor White
    Write-Host "   • Different mass objects and force applications" -ForegroundColor White
    Write-Host "   • Visual force vectors and acceleration indicators" -ForegroundColor White
    Write-Host ""
}

# Main Script Execution
Show-Header

switch($Action.ToLower()) {
    "check" {
        $editorInstalled = Check-UnityInstallation
        Write-Host ""
        Show-ProjectInfo
        Show-NextSteps -EditorInstalled $editorInstalled
        Show-PhysicsModules
    }
    "launch" {
        Launch-UnityHub
    }
    "help" {
        Write-Host "Available commands:" -ForegroundColor Cyan
        Write-Host "  .\UnityHelper.ps1 check   - Check installation status" -ForegroundColor White
        Write-Host "  .\UnityHelper.ps1 launch  - Launch Unity Hub" -ForegroundColor White
        Write-Host "  .\UnityHelper.ps1 help    - Show this help" -ForegroundColor White
    }
    default {
        Write-Host "Unknown action: $Action" -ForegroundColor Red
        Write-Host "Use: .\UnityHelper.ps1 help" -ForegroundColor Yellow
    }
}

Write-Host ""
Write-Host "🎯 Your AR Physics Explorer is ready to run!" -ForegroundColor Green
Write-Host "📖 Check RUN_CHECKLIST.md for detailed step-by-step instructions" -ForegroundColor Yellow