# AR Physics Explorer

An interactive Augmented Reality mobile application that demonstrates fundamental physics principles through immersive AR experiences. Built with Unity and AR Foundation.

## 🎯 Features

### Three Physics Modules:

1. **Ohm's Law Module (V = IR)**
   - Interactive circuit simulation with battery, resistor, and measuring instruments
   - Real-time voltage, current, and resistance calculations
   - Visual effects showing electron flow and wire glow
   - Heat visualization on components based on power dissipation

2. **Kinematic Motion Module (v = u + at)**
   - Projectile motion simulator with adjustable parameters
   - Interactive launcher with angle and velocity controls
   - Real-time trajectory prediction and visualization
   - Physics calculations displayed during motion

3. **Force and Motion Module (F = ma)**
   - Interactive force application on objects with different masses
   - Visual force and acceleration vectors
   - Real-time acceleration calculations
   - Multiple mass objects to demonstrate varying effects

## 🚀 Getting Started

### Prerequisites

- **Unity 2021.3 LTS or later**
- **Android SDK** (for Android builds)
- **Xcode** (for iOS builds)
- **AR-capable mobile device** (Android 7.0+ with ARCore support or iOS 11.0+ with ARKit support)

### Installation Steps

1. **Clone or Download the Project**
   ```bash
   git clone <repository-url>
   cd ARPhysicsApp
   ```

2. **Open in Unity**
   - Open Unity Hub
   - Click "Add" and select the `ARPhysicsApp` folder
   - Open the project with Unity 2021.3 LTS or later

3. **Install AR Foundation Packages**
   The project includes the necessary packages in `Packages/manifest.json`:
   - AR Foundation 4.2.7
   - ARCore XR Plugin 4.2.7 (Android)
   - ARKit XR Plugin 4.2.7 (iOS)

4. **Configure Build Settings**
   
   **For Android:**
   - File → Build Settings → Android
   - Player Settings → XR Plug-in Management → Enable ARCore
   - Set Minimum API Level to 24 (Android 7.0)
   - Enable "ARCore Supported" in XR Settings

   **For iOS:**
   - File → Build Settings → iOS
   - Player Settings → XR Plug-in Management → Enable ARKit
   - Set Target minimum iOS Version to 11.0
   - Camera Usage Description: "This app uses the camera for AR physics simulations"

## 🏗️ Project Structure

```
ARPhysicsApp/
├── Assets/
│   ├── Scenes/
│   │   └── MainScene.unity          # Main AR scene
│   ├── Scripts/
│   │   ├── ARPhysicsManager.cs      # Main AR management and module switching
│   │   ├── OhmsLawModule.cs         # Ohm's law physics simulation
│   │   ├── KinematicModule.cs       # Projectile motion simulation
│   │   ├── ForceModule.cs           # Force and acceleration simulation
│   │   └── ARTouchInteractionFixed.cs # Touch interaction handling
│   ├── Prefabs/                     # Physics module prefabs
│   ├── Materials/                   # Visual materials and shaders
│   ├── Textures/                    # UI and visual textures
│   └── UI/                          # User interface prefabs
├── Packages/
│   └── manifest.json                # Package dependencies
└── ProjectSettings/
    └── ProjectSettings.asset        # Unity project configuration
```

## 📱 How to Use

### Setup and Navigation

1. **Launch the App**
   - Point your device camera at a flat surface
   - Wait for plane detection (white wireframe overlay)

2. **Select a Physics Module**
   - Choose from three available modules:
     - ⚡ Ohm's Law (V = IR)
     - 🚀 Kinematic Motion (v = u + at)
     - 💪 Force & Motion (F = ma)

3. **Place the Module**
   - Tap on a detected plane to place the selected physics simulation
   - The module will appear in AR space

### Module Interactions

#### Ohm's Law Module
- **Voltage Slider**: Adjust battery voltage (1-12V)
- **Resistance Slider**: Change resistor value (1-100Ω)
- **Visual Feedback**: 
  - Wire glow intensity based on current
  - Particle effects showing electron flow
  - Component heating effects
- **Real-time Calculations**: I = V/R displayed continuously

#### Kinematic Module
- **Initial Velocity**: Set projectile launch speed (1-30 m/s)
- **Launch Angle**: Adjust trajectory angle (15-75°)
- **Acceleration**: Modify gravity effect (-15 to -5 m/s²)
- **Launch Button**: Fire the projectile and observe motion
- **Visual Elements**:
  - Trajectory prediction line
  - Particle trail effects
  - Real-time velocity and time display

#### Force Module
- **Force Slider**: Apply different forces (1-50N)
- **Mass Selection**: Choose from 5 different mass objects
- **Apply Force Button**: Watch acceleration in action
- **Visual Indicators**:
  - Force vector arrows
  - Acceleration visualization
  - Object movement based on F=ma

## 🛠️ Technical Implementation

### Key Scripts Overview

#### ARPhysicsManager.cs
- Manages AR Foundation components (ARCamera, ARPlaneManager, ARRaycastManager)
- Handles module selection and placement
- Controls UI navigation and plane detection

#### Physics Modules
Each module implements:
- **Real-time calculations** using physics formulas
- **Interactive UI controls** with sliders and buttons
- **Visual effects** using Unity's particle systems and line renderers
- **Camera-facing UI panels** for optimal AR viewing

#### Touch Interactions
- **Single touch**: Object selection and dragging
- **Two-finger gestures**: Scaling and rotation
- **AR raycasting** for accurate world-space interactions

### AR Foundation Features Used
- **Plane Detection**: Horizontal surface detection for module placement
- **Camera Rendering**: Real-world camera feed with virtual overlays
- **Raycasting**: Touch-to-world position conversion
- **Session Management**: AR state handling and persistence

## 🎓 Educational Value

### Learning Objectives
Students will be able to:

1. **Ohm's Law Understanding**
   - Visualize the relationship between voltage, current, and resistance
   - Observe how changing one variable affects others
   - Understand power dissipation and heating effects

2. **Kinematic Motion Concepts**
   - Explore projectile motion principles
   - Understand velocity, acceleration, and time relationships
   - Visualize trajectory effects of angle and initial velocity

3. **Force and Motion Principles**
   - Experience Newton's second law in action
   - Compare acceleration effects on different masses
   - Understand the relationship between force, mass, and acceleration

### Interactive Learning Benefits
- **Visual Learning**: 3D visualizations make abstract concepts tangible
- **Experimentation**: Safe environment to test different scenarios
- **Real-time Feedback**: Immediate results encourage exploration
- **Immersive Experience**: AR creates engaging, memorable learning moments

## 🔧 Development Notes

### Performance Optimization
- **Efficient Physics Calculations**: Optimized update loops
- **Smart UI Updates**: Only update display when values change
- **Particle System Management**: Controlled emission rates
- **Memory Management**: Proper object cleanup and reuse

### Cross-Platform Considerations
- **AR Foundation Compatibility**: Works on both ARCore (Android) and ARKit (iOS)
- **Responsive UI**: Adapts to different screen sizes and orientations
- **Touch Input Handling**: Supports various touch gestures consistently

### Extensibility
The modular architecture allows for:
- **Easy addition of new physics modules**
- **Customizable visualization effects**
- **Adjustable difficulty levels**
- **Additional interactive elements**

## 📋 Build and Deployment

### Android Build Process
1. Set Build Target to Android
2. Configure Player Settings (API level, permissions)
3. Enable ARCore in XR Plug-in Management
4. Build and install APK on ARCore-supported device

### iOS Build Process
1. Set Build Target to iOS
2. Configure Player Settings (iOS version, camera permissions)
3. Enable ARKit in XR Plug-in Management
4. Build Xcode project and deploy to ARKit-supported device

### Required Permissions
- **Camera**: Essential for AR functionality
- **Storage**: For saving app preferences (optional)

## 🤝 Contributing

To add new physics modules:
1. Create new script inheriting from MonoBehaviour
2. Implement physics calculations and UI interactions
3. Add visual effects using Unity's systems
4. Register with ARPhysicsManager for module selection

## 📄 License

This educational AR physics application is designed for learning purposes. Please ensure proper attribution when using or modifying the code.

## 🆘 Troubleshooting

### Common Issues

**AR not working:**
- Ensure device supports ARCore/ARKit
- Check camera permissions
- Verify good lighting conditions
- Point camera at textured, flat surfaces

**Performance issues:**
- Close other apps to free memory
- Reduce particle system intensity
- Check device specifications

**Touch interactions not working:**
- Ensure objects have colliders
- Check ARTouchInteraction script is enabled
- Verify proper layer settings

### Device Requirements
- **Android**: Version 7.0+ with ARCore support
- **iOS**: Version 11.0+ with A9 processor or newer
- **RAM**: Minimum 3GB recommended
- **Storage**: 100MB+ available space

## 📞 Support

For technical support or educational inquiries, please refer to the Unity AR Foundation documentation or contact the development team.