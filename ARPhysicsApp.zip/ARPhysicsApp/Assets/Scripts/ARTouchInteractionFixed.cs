using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.XR.ARFoundation;
using UnityEngine.XR.ARSubsystems;

public class ARTouchInteraction : MonoBehaviour
{
    [Header("AR Components")]
    public ARRaycastManager raycastManager;
    public ARCamera arCamera;
    
    [Header("Interaction Settings")]
    public float dragSensitivity = 2f;
    public float scaleSensitivity = 1f;
    public float rotationSensitivity = 50f;
    
    private List<ARRaycastHit> raycastHits = new List<ARRaycastHit>();
    private GameObject selectedObject;
    private Vector3 lastTouchPosition;
    private bool isDragging = false;
    private bool isScaling = false;
    private bool isRotating = false;
    private float lastPinchDistance = 0f;
    
    void Update()
    {
        HandleTouchInput();
    }
    
    void HandleTouchInput()
    {
        if(Input.touchCount == 1)
        {
            HandleSingleTouch();
        }
        else if(Input.touchCount == 2)
        {
            HandleTwoFingerGestures();
        }
        else if(Input.touchCount == 0 && selectedObject != null)
        {
            ReleaseSelectedObject();
        }
    }
    
    void HandleSingleTouch()
    {
        Touch touch = Input.GetTouch(0);
        
        switch(touch.phase)
        {
            case TouchPhase.Began:
                TrySelectObject(touch.position);
                break;
                
            case TouchPhase.Moved:
                if(selectedObject != null && isDragging)
                {
                    DragSelectedObject(touch.position);
                }
                break;
                
            case TouchPhase.Ended:
            case TouchPhase.Canceled:
                ReleaseSelectedObject();
                break;
        }
    }
    
    void HandleTwoFingerGestures()
    {
        if(selectedObject == null) return;
        
        Touch touch1 = Input.GetTouch(0);
        Touch touch2 = Input.GetTouch(1);
        
        // Calculate pinch distance for scaling
        float currentPinchDistance = Vector2.Distance(touch1.position, touch2.position);
        
        if(touch1.phase == TouchPhase.Began || touch2.phase == TouchPhase.Began)
        {
            lastPinchDistance = currentPinchDistance;
            isScaling = true;
        }
        else if((touch1.phase == TouchPhase.Moved || touch2.phase == TouchPhase.Moved) && isScaling)
        {
            ScaleSelectedObject(currentPinchDistance);
            lastPinchDistance = currentPinchDistance;
        }
        else if(touch1.phase == TouchPhase.Ended || touch2.phase == TouchPhase.Ended)
        {
            isScaling = false;
        }
    }
    
    void TrySelectObject(Vector2 screenPosition)
    {
        // First try AR raycast to detect physics modules
        if(raycastManager.Raycast(screenPosition, raycastHits, TrackableType.PlaneWithinPolygon))
        {
            // Check if we hit an interactable object
            Ray ray = arCamera.ScreenPointToRay(screenPosition);
            RaycastHit hit;
            
            if(Physics.Raycast(ray, out hit))
            {
                GameObject hitObject = hit.collider.gameObject;
                
                // Check if the object is interactable (has specific components)
                if(IsInteractableObject(hitObject))
                {
                    SelectObject(hitObject, hit.point);
                }
            }
        }
        
        // If no AR object selected, try regular screen-to-world raycast
        if(selectedObject == null)
        {
            Ray screenRay = arCamera.ScreenPointToRay(screenPosition);
            RaycastHit screenHit;
            
            if(Physics.Raycast(screenRay, out screenHit))
            {
                GameObject hitObject = screenHit.collider.gameObject;
                if(IsInteractableObject(hitObject))
                {
                    SelectObject(hitObject, screenHit.point);
                }
            }
        }
    }
    
    bool IsInteractableObject(GameObject obj)
    {
        // Check if object has physics components or is part of a physics module
        return obj.GetComponent<Rigidbody>() != null || 
               obj.GetComponentInParent<OhmsLawModule>() != null ||
               obj.GetComponentInParent<KinematicModule>() != null ||
               obj.GetComponentInParent<ForceModule>() != null ||
               obj.CompareTag("Interactable");
    }
    
    void SelectObject(GameObject obj, Vector3 hitPoint)
    {
        selectedObject = obj;
        lastTouchPosition = hitPoint;
        isDragging = true;
        
        // Add visual feedback
        AddSelectionFeedback(obj);
    }
    
    void DragSelectedObject(Vector2 screenPosition)
    {
        if(selectedObject == null) return;
        
        // Convert screen position to world position on the AR plane
        if(raycastManager.Raycast(screenPosition, raycastHits, TrackableType.PlaneWithinPolygon))
        {
            Vector3 worldPosition = raycastHits[0].pose.position;
            Vector3 deltaPosition = worldPosition - lastTouchPosition;
            
            // Move the selected object
            selectedObject.transform.position += deltaPosition;
            lastTouchPosition = worldPosition;
            
            // Update physics if object has rigidbody
            Rigidbody rb = selectedObject.GetComponent<Rigidbody>();
            if(rb != null)
            {
                rb.velocity = Vector3.zero; // Stop physics momentum while dragging
            }
        }
    }
    
    void ScaleSelectedObject(float currentPinchDistance)
    {
        if(selectedObject == null || lastPinchDistance == 0) return;
        
        float scaleFactor = currentPinchDistance / lastPinchDistance;
        scaleFactor = Mathf.Clamp(scaleFactor, 0.5f, 2f); // Limit scaling range
        
        Vector3 newScale = selectedObject.transform.localScale * scaleFactor;
        newScale = Vector3.ClampMagnitude(newScale, 5f); // Prevent objects from becoming too large
        
        if(newScale.magnitude > 0.1f) // Prevent objects from becoming too small
        {
            selectedObject.transform.localScale = newScale;
        }
    }
    
    void ReleaseSelectedObject()
    {
        if(selectedObject != null)
        {
            // Remove visual feedback
            RemoveSelectionFeedback(selectedObject);
            selectedObject = null;
        }
        
        isDragging = false;
        isScaling = false;
        isRotating = false;
    }
    
    void AddSelectionFeedback(GameObject obj)
    {
        // Add outline or highlight effect
        Renderer renderer = obj.GetComponent<Renderer>();
        if(renderer != null)
        {
            renderer.material.color = Color.yellow;
        }
    }
    
    void RemoveSelectionFeedback(GameObject obj)
    {
        // Remove outline or highlight effect
        Renderer renderer = obj.GetComponent<Renderer>();
        if(renderer != null)
        {
            renderer.material.color = Color.white;
        }
    }
    
    // Public method to enable/disable touch interaction
    public void SetInteractionEnabled(bool enabled)
    {
        this.enabled = enabled;
        
        if(!enabled)
        {
            ReleaseSelectedObject();
        }
    }
    
    // Public method to check if an object is currently selected
    public bool IsObjectSelected(GameObject obj)
    {
        return selectedObject == obj;
    }
    
    // Public method to force release current selection
    public void ForceReleaseSelection()
    {
        ReleaseSelectedObject();
    }
}