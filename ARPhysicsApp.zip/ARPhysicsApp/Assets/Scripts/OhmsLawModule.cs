using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class OhmsLawModule : MonoBehaviour
{
    [Header("Circuit Components")]
    public GameObject battery;
    public GameObject resistor;
    public GameObject ammeter;
    public GameObject voltmeter;
    public LineRenderer wireRenderer;
    
    [Header("UI Controls")]
    public Slider voltageSlider;
    public Slider resistanceSlider;
    public Text voltageValueText;
    public Text resistanceValueText;
    public Text currentValueText;
    public Text formulaText;
    public GameObject uiPanel;
    
    [Header("Visual Effects")]
    public ParticleSystem electronFlow;
    public Material wireGlowMaterial;
    public Color lowCurrentColor = Color.blue;
    public Color highCurrentColor = Color.red;
    
    [Header("Circuit Values")]
    [Range(1f, 12f)]
    public float voltage = 6f;
    [Range(1f, 100f)]
    public float resistance = 10f;
    
    private float current;
    private float maxCurrent = 5f;
    
    void Start()
    {
        SetupUI();
        SetupCircuitVisualization();
        CalculateOhmsLaw();
    }
    
    void SetupUI()
    {
        // Setup sliders
        voltageSlider.minValue = 1f;
        voltageSlider.maxValue = 12f;
        voltageSlider.value = voltage;
        voltageSlider.onValueChanged.AddListener(OnVoltageChanged);
        
        resistanceSlider.minValue = 1f;
        resistanceSlider.maxValue = 100f;
        resistanceSlider.value = resistance;
        resistanceSlider.onValueChanged.AddListener(OnResistanceChanged);
        
        // Set formula text
        formulaText.text = "Ohm's Law: V = I × R";
        
        // Position UI panel relative to the module
        uiPanel.transform.SetParent(this.transform);
        uiPanel.transform.localPosition = new Vector3(0, 1.5f, 0);
        uiPanel.transform.LookAt(Camera.main.transform);
        uiPanel.transform.Rotate(0, 180, 0); // Face the camera
    }
    
    void SetupCircuitVisualization()
    {
        // Setup wire visualization
        if(wireRenderer != null)
        {
            Vector3[] wirePoints = new Vector3[]
            {
                battery.transform.localPosition,
                new Vector3(0.5f, 0, 0),
                resistor.transform.localPosition,
                new Vector3(-0.5f, 0, 0),
                battery.transform.localPosition
            };
            
            wireRenderer.positionCount = wirePoints.Length;
            wireRenderer.SetPositions(wirePoints);
            wireRenderer.material = wireGlowMaterial;
            wireRenderer.startWidth = 0.02f;
            wireRenderer.endWidth = 0.02f;
        }
        
        // Position circuit components
        if(battery != null) battery.transform.localPosition = new Vector3(-0.5f, 0, -0.3f);
        if(resistor != null) resistor.transform.localPosition = new Vector3(0.5f, 0, 0.3f);
        if(ammeter != null) ammeter.transform.localPosition = new Vector3(0, 0, 0.5f);
        if(voltmeter != null) voltmeter.transform.localPosition = new Vector3(0, 0, -0.5f);
    }
    
    public void OnVoltageChanged(float newVoltage)
    {
        voltage = newVoltage;
        CalculateOhmsLaw();
        UpdateVisualization();
    }
    
    public void OnResistanceChanged(float newResistance)
    {
        resistance = newResistance;
        CalculateOhmsLaw();
        UpdateVisualization();
    }
    
    void CalculateOhmsLaw()
    {
        // Calculate current using Ohm's law: I = V / R
        current = voltage / resistance;
        
        // Update UI text
        voltageValueText.text = $"Voltage: {voltage:F1} V";
        resistanceValueText.text = $"Resistance: {resistance:F1} Ω";
        currentValueText.text = $"Current: {current:F2} A";
    }
    
    void UpdateVisualization()
    {
        // Update wire color based on current
        float currentRatio = Mathf.Clamp01(current / maxCurrent);
        Color wireColor = Color.Lerp(lowCurrentColor, highCurrentColor, currentRatio);
        
        if(wireGlowMaterial != null)
        {
            wireGlowMaterial.SetColor("_EmissionColor", wireColor * currentRatio);
        }
        
        // Update electron flow particles
        if(electronFlow != null)
        {
            var emission = electronFlow.emission;
            emission.rateOverTime = current * 10f; // More current = more particles
            
            var velocity = electronFlow.velocityOverLifetime;
            velocity.enabled = true;
            velocity.space = ParticleSystemSimulationSpace.Local;
            velocity.linear = new ParticleSystem.MinMaxCurve(current * 2f, Vector3.right);
        }
        
        // Animate circuit components
        AnimateComponents();
    }
    
    void AnimateComponents()
    {
        // Battery animation - pulse based on voltage
        if(battery != null)
        {
            float pulseScale = 1f + (voltage / 12f) * 0.1f;
            battery.transform.localScale = Vector3.one * pulseScale;
        }
        
        // Resistor animation - heat effect based on power (I²R)
        if(resistor != null)
        {
            float power = current * current * resistance;
            float heatEffect = Mathf.Sin(Time.time * power) * 0.02f + 1f;
            resistor.transform.localScale = Vector3.one * heatEffect;
            
            // Color change for heat
            Renderer resistorRenderer = resistor.GetComponent<Renderer>();
            if(resistorRenderer != null)
            {
                float heatRatio = Mathf.Clamp01(power / 10f);
                Color heatColor = Color.Lerp(Color.yellow, Color.red, heatRatio);
                resistorRenderer.material.color = heatColor;
            }
        }
    }
    
    void Update()
    {
        // Keep UI panel facing the camera
        if(uiPanel != null && Camera.main != null)
        {
            Vector3 directionToCamera = Camera.main.transform.position - uiPanel.transform.position;
            uiPanel.transform.rotation = Quaternion.LookRotation(-directionToCamera);
        }
    }
    
    void OnEnable()
    {
        CalculateOhmsLaw();
        UpdateVisualization();
    }
    
    // Public method to reset the simulation
    public void ResetSimulation()
    {
        voltage = 6f;
        resistance = 10f;
        voltageSlider.value = voltage;
        resistanceSlider.value = resistance;
        CalculateOhmsLaw();
        UpdateVisualization();
    }
    
    // Method to demonstrate different scenarios
    public void DemonstrateScenario(string scenario)
    {
        switch(scenario.ToLower())
        {
            case "high_voltage":
                voltageSlider.value = 12f;
                break;
            case "high_resistance":
                resistanceSlider.value = 100f;
                break;
            case "low_resistance":
                resistanceSlider.value = 1f;
                break;
            case "balanced":
                voltageSlider.value = 6f;
                resistanceSlider.value = 10f;
                break;
        }
    }
}