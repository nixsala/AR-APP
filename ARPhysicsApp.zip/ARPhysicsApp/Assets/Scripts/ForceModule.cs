using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class ForceModule : MonoBehaviour
{
    [Header("Physics Objects")]
    public GameObject[] massObjects; // Array of objects with different masses
    public GameObject forceIndicator; // Arrow showing applied force
    public ParticleSystem forceEffect;
    public LineRenderer accelerationVector;
    
    [Header("UI Controls")]
    public Slider forceSlider;
    public Slider massSlider;
    public Button applyForceButton;
    public Button resetButton;
    public Dropdown massObjectDropdown;
    public Text forceValueText;
    public Text massValueText;
    public Text accelerationValueText;
    public Text formulaText;
    public GameObject uiPanel;
    
    [Header("Visualization")]
    public Material vectorMaterial;
    public Color forceColor = Color.red;
    public Color accelerationColor = Color.blue;
    public float maxVectorLength = 2f;
    
    [Header("Physics Values")]
    [Range(1f, 50f)]
    public float appliedForce = 10f;
    [Range(0.5f, 10f)]
    public float objectMass = 2f;
    
    private GameObject currentObject;
    private Rigidbody currentRigidbody;
    private float calculatedAcceleration;
    private bool isForceApplied = false;
    private Vector3 originalPosition;
    private float[] predefinedMasses = {0.5f, 1f, 2f, 5f, 10f};
    private string[] massLabels = {"Light Ball (0.5kg)", "Tennis Ball (1kg)", "Bowling Ball (2kg)", "Heavy Block (5kg)", "Very Heavy Block (10kg)"};
    
    void Start()
    {
        SetupUI();
        SetupPhysicsObjects();
        CalculateNewtonSecondLaw();
        UpdateVisualization();
    }
    
    void SetupUI()
    {
        // Setup sliders
        forceSlider.minValue = 1f;
        forceSlider.maxValue = 50f;
        forceSlider.value = appliedForce;
        forceSlider.onValueChanged.AddListener(OnForceChanged);
        
        massSlider.minValue = 0.5f;
        massSlider.maxValue = 10f;
        massSlider.value = objectMass;
        massSlider.onValueChanged.AddListener(OnMassChanged);
        
        // Setup dropdown for mass objects
        massObjectDropdown.options.Clear();
        for(int i = 0; i < massLabels.Length; i++)
        {
            massObjectDropdown.options.Add(new Dropdown.OptionData(massLabels[i]));
        }
        massObjectDropdown.value = 2; // Default to bowling ball
        massObjectDropdown.onValueChanged.AddListener(OnMassObjectChanged);
        
        // Setup buttons
        applyForceButton.onClick.AddListener(ApplyForce);
        resetButton.onClick.AddListener(ResetSimulation);
        
        // Set formula text
        formulaText.text = "Newton's Second Law: F = ma";
        
        // Position UI panel relative to the module
        uiPanel.transform.SetParent(this.transform);
        uiPanel.transform.localPosition = new Vector3(0, 1.5f, 0);
    }
    
    void SetupPhysicsObjects()
    {
        // Setup mass objects with different properties
        for(int i = 0; i < massObjects.Length && i < predefinedMasses.Length; i++)
        {
            if(massObjects[i] != null)
            {
                Rigidbody rb = massObjects[i].GetComponent<Rigidbody>();
                if(rb == null)
                {
                    rb = massObjects[i].AddComponent<Rigidbody>();
                }
                
                rb.mass = predefinedMasses[i];
                rb.drag = 2f; // Add some drag for better control
                rb.angularDrag = 5f;
                
                // Position objects in a line
                massObjects[i].transform.localPosition = new Vector3(i * 0.5f - 1f, 0.2f, 0);
                massObjects[i].SetActive(i == 2); // Show bowling ball by default
            }
        }
        
        // Set current object to default (bowling ball)
        SetCurrentObject(2);
        
        // Setup force indicator
        if(forceIndicator != null)
        {
            forceIndicator.transform.localPosition = new Vector3(0, 0.5f, 0);
            forceIndicator.SetActive(false);
        }
        
        // Setup acceleration vector visualization
        if(accelerationVector != null)
        {
            accelerationVector.material = vectorMaterial;
            accelerationVector.startWidth = 0.05f;
            accelerationVector.endWidth = 0.02f;
            accelerationVector.positionCount = 2;
            accelerationVector.enabled = false;
        }
    }
    
    void SetCurrentObject(int index)
    {
        // Hide all objects first
        foreach(GameObject obj in massObjects)
        {
            if(obj != null) obj.SetActive(false);
        }
        
        // Show and set current object
        if(index < massObjects.Length && massObjects[index] != null)
        {
            currentObject = massObjects[index];
            currentObject.SetActive(true);
            currentRigidbody = currentObject.GetComponent<Rigidbody>();
            objectMass = currentRigidbody.mass;
            originalPosition = currentObject.transform.position;
            
            // Update mass slider to match object
            massSlider.value = objectMass;
        }
    }
    
    public void OnForceChanged(float newForce)
    {
        appliedForce = newForce;
        CalculateNewtonSecondLaw();
        UpdateVisualization();
    }
    
    public void OnMassChanged(float newMass)
    {
        objectMass = newMass;
        if(currentRigidbody != null)
        {
            currentRigidbody.mass = objectMass;
        }
        CalculateNewtonSecondLaw();
        UpdateVisualization();
    }
    
    public void OnMassObjectChanged(int objectIndex)
    {
        SetCurrentObject(objectIndex);
        CalculateNewtonSecondLaw();
        UpdateVisualization();
    }
    
    void CalculateNewtonSecondLaw()
    {
        // Calculate acceleration using Newton's second law: a = F / m
        calculatedAcceleration = appliedForce / objectMass;
        
        // Update UI text
        forceValueText.text = $"Applied Force (F): {appliedForce:F1} N";
        massValueText.text = $"Mass (m): {objectMass:F1} kg";
        accelerationValueText.text = $"Acceleration (a): {calculatedAcceleration:F2} m/s²";
    }
    
    void UpdateVisualization()
    {
        if(!isForceApplied)
        {
            UpdateForceIndicator();
            UpdateAccelerationVector();
        }
    }
    
    void UpdateForceIndicator()
    {
        if(forceIndicator != null && currentObject != null)
        {
            // Position force indicator next to current object
            Vector3 indicatorPosition = currentObject.transform.position + Vector3.up * 0.3f + Vector3.left * 0.3f;
            forceIndicator.transform.position = indicatorPosition;
            
            // Scale force indicator based on force magnitude
            float forceScale = Mathf.Clamp(appliedForce / 25f, 0.5f, 2f);
            forceIndicator.transform.localScale = Vector3.one * forceScale;
            
            // Color based on force magnitude
            Renderer indicatorRenderer = forceIndicator.GetComponent<Renderer>();
            if(indicatorRenderer != null)
            {
                float intensity = appliedForce / 50f;
                Color indicatorColor = Color.Lerp(Color.yellow, forceColor, intensity);
                indicatorRenderer.material.color = indicatorColor;
            }
            
            forceIndicator.SetActive(true);
        }
    }
    
    void UpdateAccelerationVector()
    {
        if(accelerationVector != null && currentObject != null)
        {
            Vector3 startPoint = currentObject.transform.position + Vector3.up * 0.1f;
            float vectorLength = Mathf.Clamp(calculatedAcceleration / 10f, 0.1f, maxVectorLength);
            Vector3 endPoint = startPoint + Vector3.right * vectorLength;
            
            accelerationVector.SetPosition(0, startPoint);
            accelerationVector.SetPosition(1, endPoint);
            accelerationVector.color = accelerationColor;
            accelerationVector.enabled = true;
        }
    }
    
    public void ApplyForce()
    {
        if(isForceApplied || currentRigidbody == null) return;
        
        // Hide visualization elements during force application
        if(forceIndicator != null) forceIndicator.SetActive(false);
        if(accelerationVector != null) accelerationVector.enabled = false;
        
        // Apply force to the right
        Vector3 forceVector = Vector3.right * appliedForce;
        currentRigidbody.AddForce(forceVector, ForceMode.Impulse);
        
        // Enable force effect
        if(forceEffect != null)
        {
            forceEffect.transform.position = currentObject.transform.position;
            forceEffect.Play();
        }
        
        isForceApplied = true;
        StartCoroutine(MonitorForceApplication());
    }
    
    IEnumerator MonitorForceApplication()
    {
        yield return new WaitForSeconds(3f); // Let physics play out
        
        // Auto reset after some time or when object stops moving
        while(currentRigidbody != null && currentRigidbody.velocity.magnitude > 0.1f)
        {
            yield return new WaitForSeconds(0.5f);
        }
        
        yield return new WaitForSeconds(1f);
        AutoReset();
    }
    
    void AutoReset()
    {
        if(!isForceApplied) return;
        
        // Reset object position and velocity
        if(currentObject != null && currentRigidbody != null)
        {
            currentRigidbody.velocity = Vector3.zero;
            currentRigidbody.angularVelocity = Vector3.zero;
            currentObject.transform.position = originalPosition;
        }
        
        // Stop force effect
        if(forceEffect != null && forceEffect.isPlaying)
        {
            forceEffect.Stop();
        }
        
        isForceApplied = false;
        UpdateVisualization();
    }
    
    public void ResetSimulation()
    {
        // Stop any ongoing force application
        StopAllCoroutines();
        
        // Reset object
        if(currentObject != null && currentRigidbody != null)
        {
            currentRigidbody.velocity = Vector3.zero;
            currentRigidbody.angularVelocity = Vector3.zero;
            currentObject.transform.position = originalPosition;
        }
        
        // Stop effects
        if(forceEffect != null && forceEffect.isPlaying)
        {
            forceEffect.Stop();
        }
        
        isForceApplied = false;
        CalculateNewtonSecondLaw();
        UpdateVisualization();
    }
    
    void Update()
    {
        // Keep UI panel facing the camera
        if(uiPanel != null && Camera.main != null)
        {
            Vector3 directionToCamera = Camera.main.transform.position - uiPanel.transform.position;
            uiPanel.transform.rotation = Quaternion.LookRotation(-directionToCamera);
        }
        
        // Update calculations during force application for real-time feedback
        if(isForceApplied && currentRigidbody != null)
        {
            float currentAcceleration = currentRigidbody.velocity.magnitude / Time.fixedDeltaTime;
            accelerationValueText.text = $"Current Acceleration: {currentAcceleration:F2} m/s²";
        }
    }
    
    void OnEnable()
    {
        ResetSimulation();
    }
    
    // Method to demonstrate different scenarios
    public void DemonstrateScenario(string scenario)
    {
        switch(scenario.ToLower())
        {
            case "light_object":
                massObjectDropdown.value = 0; // Light ball
                break;
            case "heavy_object":
                massObjectDropdown.value = 4; // Very heavy block
                break;
            case "high_force":
                forceSlider.value = 40f;
                break;
            case "low_force":
                forceSlider.value = 5f;
                break;
            case "equal_force_different_mass":
                // Demonstrate same force on different masses
                forceSlider.value = 20f;
                break;
        }
    }
    
    // Method to compare accelerations of different masses with same force
    public void CompareAccelerations()
    {
        StartCoroutine(ComparisonDemo());
    }
    
    IEnumerator ComparisonDemo()
    {
        float originalForce = appliedForce;
        
        // Show light object
        massObjectDropdown.value = 0;
        yield return new WaitForSeconds(1f);
        ApplyForce();
        yield return new WaitForSeconds(4f);
        
        // Show heavy object with same force
        ResetSimulation();
        massObjectDropdown.value = 4;
        forceSlider.value = originalForce;
        yield return new WaitForSeconds(1f);
        ApplyForce();
    }
}