using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.XR.ARFoundation;
using UnityEngine.XR.ARSubsystems;
using UnityEngine.UI;

public class ARPhysicsManager : MonoBehaviour
{
    [Header("AR Components")]
    public ARSessionOrigin arSessionOrigin;
    public ARPlaneManager planeManager;
    public ARRaycastManager raycastManager;
    public ARCamera arCamera;
    
    [Header("Physics Modules")]
    public GameObject ohmsLawModule;
    public GameObject kinematicModule; 
    public GameObject forceModule;
    
    [Header("UI Elements")]
    public GameObject mainMenu;
    public Button ohmsLawButton;
    public Button kinematicButton;
    public Button forceButton;
    public Button backButton;
    public Text instructionText;
    
    private GameObject currentActiveModule;
    private List<ARRaycastHit> raycastHits = new List<ARRaycastHit>();
    private bool isPlacementMode = false;
    
    public enum PhysicsModule
    {
        None,
        OhmsLaw,
        Kinematic,
        Force
    }
    
    private PhysicsModule currentModule = PhysicsModule.None;
    
    void Start()
    {
        InitializeAR();
        SetupUI();
        ShowMainMenu();
    }
    
    void InitializeAR()
    {
        // Enable plane detection
        planeManager.enabled = true;
        planeManager.requestedDetectionMode = PlaneDetectionMode.Horizontal;
        
        // Set instruction text
        instructionText.text = "Point your camera at a flat surface to detect planes";
    }
    
    void SetupUI()
    {
        ohmsLawButton.onClick.AddListener(() => SelectModule(PhysicsModule.OhmsLaw));
        kinematicButton.onClick.AddListener(() => SelectModule(PhysicsModule.Kinematic));
        forceButton.onClick.AddListener(() => SelectModule(PhysicsModule.Force));
        backButton.onClick.AddListener(ShowMainMenu);
        
        backButton.gameObject.SetActive(false);
    }
    
    public void SelectModule(PhysicsModule module)
    {
        currentModule = module;
        mainMenu.SetActive(false);
        backButton.gameObject.SetActive(true);
        isPlacementMode = true;
        
        switch(module)
        {
            case PhysicsModule.OhmsLaw:
                instructionText.text = "Tap on a detected plane to place the Ohm's Law circuit";
                break;
            case PhysicsModule.Kinematic:
                instructionText.text = "Tap on a detected plane to place the projectile motion simulator";
                break;
            case PhysicsModule.Force:
                instructionText.text = "Tap on a detected plane to place the force demonstration";
                break;
        }
    }
    
    public void ShowMainMenu()
    {
        if(currentActiveModule != null)
        {
            currentActiveModule.SetActive(false);
            currentActiveModule = null;
        }
        
        currentModule = PhysicsModule.None;
        mainMenu.SetActive(true);
        backButton.gameObject.SetActive(false);
        isPlacementMode = false;
        instructionText.text = "Choose a Physics Module to Explore";
    }
    
    void Update()
    {
        if(isPlacementMode && Input.touchCount > 0)
        {
            Touch touch = Input.GetTouch(0);
            
            if(touch.phase == TouchPhase.Began)
            {
                Vector2 touchPosition = touch.position;
                
                if(raycastManager.Raycast(touchPosition, raycastHits, TrackableType.PlaneWithinPolygon))
                {
                    PlaceModule(raycastHits[0].pose);
                }
            }
        }
    }
    
    void PlaceModule(Pose pose)
    {
        if(currentActiveModule != null)
        {
            currentActiveModule.SetActive(false);
        }
        
        GameObject moduleToPlace = null;
        
        switch(currentModule)
        {
            case PhysicsModule.OhmsLaw:
                moduleToPlace = ohmsLawModule;
                break;
            case PhysicsModule.Kinematic:
                moduleToPlace = kinematicModule;
                break;
            case PhysicsModule.Force:
                moduleToPlace = forceModule;
                break;
        }
        
        if(moduleToPlace != null)
        {
            moduleToPlace.transform.position = pose.position;
            moduleToPlace.transform.rotation = pose.rotation;
            moduleToPlace.SetActive(true);
            currentActiveModule = moduleToPlace;
            isPlacementMode = false;
            instructionText.text = "Module placed! Interact with the physics simulation";
        }
    }
}