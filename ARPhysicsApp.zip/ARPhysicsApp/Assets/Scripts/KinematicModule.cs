using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class KinematicModule : MonoBehaviour
{
    [Header("Projectile Components")]
    public GameObject projectile;
    public GameObject launcher;
    public LineRenderer trajectoryLine;
    public ParticleSystem trailEffect;
    
    [Header("UI Controls")]
    public Slider initialVelocitySlider;
    public Slider accelerationSlider;
    public Slider angleSlider;
    public Button launchButton;
    public Button resetButton;
    public Text initialVelocityText;
    public Text accelerationText;
    public Text angleText;
    public Text currentVelocityText;
    public Text timeText;
    public Text formulaText;
    public GameObject uiPanel;
    
    [Header("Visualization")]
    public Material trajectoryMaterial;
    public Color trajectoryColor = Color.yellow;
    public int trajectoryPoints = 50;
    public float maxTrajectoryTime = 5f;
    
    [Header("Physics Values")]
    [Range(1f, 30f)]
    public float initialVelocity = 15f;
    [Range(-10f, 10f)]
    public float acceleration = -9.81f; // gravity
    [Range(0f, 90f)]
    public float launchAngle = 45f;
    
    private Vector3 launchPosition;
    private Vector3 launchDirection;
    private bool isProjectileInMotion = false;
    private float flightTime = 0f;
    private float currentVelocity;
    private Rigidbody projectileRb;
    
    void Start()
    {
        SetupUI();
        SetupProjectile();
        CalculateKinematics();
        ShowTrajectoryPreview();
    }
    
    void SetupUI()
    {
        // Setup sliders
        initialVelocitySlider.minValue = 1f;
        initialVelocitySlider.maxValue = 30f;
        initialVelocitySlider.value = initialVelocity;
        initialVelocitySlider.onValueChanged.AddListener(OnInitialVelocityChanged);
        
        accelerationSlider.minValue = -15f;
        accelerationSlider.maxValue = -5f;
        accelerationSlider.value = acceleration;
        accelerationSlider.onValueChanged.AddListener(OnAccelerationChanged);
        
        angleSlider.minValue = 15f;
        angleSlider.maxValue = 75f;
        angleSlider.value = launchAngle;
        angleSlider.onValueChanged.AddListener(OnAngleChanged);
        
        // Setup buttons
        launchButton.onClick.AddListener(LaunchProjectile);
        resetButton.onClick.AddListener(ResetSimulation);
        
        // Set formula text
        formulaText.text = "Kinematic Equation: v = u + at";
        
        // Position UI panel relative to the module
        uiPanel.transform.SetParent(this.transform);
        uiPanel.transform.localPosition = new Vector3(0, 1.5f, 0);
    }
    
    void SetupProjectile()
    {
        if(projectile != null)
        {
            projectileRb = projectile.GetComponent<Rigidbody>();
            if(projectileRb == null)
            {
                projectileRb = projectile.AddComponent<Rigidbody>();
            }
            
            // Setup projectile physics
            projectileRb.useGravity = false; // We'll handle gravity manually for better control
            projectileRb.drag = 0.1f;
        }
        
        // Position launcher
        if(launcher != null)
        {
            launcher.transform.localPosition = new Vector3(0, 0.1f, 0);
            launchPosition = launcher.transform.position;
        }
        
        // Setup trajectory line
        if(trajectoryLine != null)
        {
            trajectoryLine.material = trajectoryMaterial;
            trajectoryLine.startWidth = 0.05f;
            trajectoryLine.endWidth = 0.02f;
            trajectoryLine.positionCount = trajectoryPoints;
        }
    }
    
    public void OnInitialVelocityChanged(float newVelocity)
    {
        initialVelocity = newVelocity;
        CalculateKinematics();
        ShowTrajectoryPreview();
    }
    
    public void OnAccelerationChanged(float newAcceleration)
    {
        acceleration = newAcceleration;
        CalculateKinematics();
        ShowTrajectoryPreview();
    }
    
    public void OnAngleChanged(float newAngle)
    {
        launchAngle = newAngle;
        CalculateKinematics();
        ShowTrajectoryPreview();
        UpdateLauncherRotation();
    }
    
    void CalculateKinematics()
    {
        // Update UI text
        initialVelocityText.text = $"Initial Velocity (u): {initialVelocity:F1} m/s";
        accelerationText.text = $"Acceleration (a): {acceleration:F1} m/s²";
        angleText.text = $"Launch Angle: {launchAngle:F0}°";
        
        // Calculate launch direction
        float angleInRadians = launchAngle * Mathf.Deg2Rad;
        launchDirection = new Vector3(
            Mathf.Cos(angleInRadians),
            Mathf.Sin(angleInRadians),
            0
        ).normalized;
        
        // Calculate current velocity if projectile is in motion
        if(isProjectileInMotion)
        {
            currentVelocity = initialVelocity + (acceleration * flightTime);
            currentVelocityText.text = $"Current Velocity (v): {currentVelocity:F1} m/s";
            timeText.text = $"Flight Time (t): {flightTime:F1} s";
        }
        else
        {
            currentVelocityText.text = $"Current Velocity (v): {initialVelocity:F1} m/s";
            timeText.text = $"Flight Time (t): 0.0 s";
        }
    }
    
    void ShowTrajectoryPreview()
    {
        if(trajectoryLine == null || isProjectileInMotion) return;
        
        Vector3[] trajectoryPoints = new Vector3[this.trajectoryPoints];
        float timeStep = maxTrajectoryTime / this.trajectoryPoints;
        
        for(int i = 0; i < this.trajectoryPoints; i++)
        {
            float t = i * timeStep;
            
            // Calculate position using kinematic equations
            // x = u*cos(θ)*t
            // y = u*sin(θ)*t + 0.5*a*t²
            float x = initialVelocity * Mathf.Cos(launchAngle * Mathf.Deg2Rad) * t;
            float y = (initialVelocity * Mathf.Sin(launchAngle * Mathf.Deg2Rad) * t) + (0.5f * acceleration * t * t);
            
            Vector3 point = launchPosition + new Vector3(x, y, 0);
            trajectoryPoints[i] = point;
            
            // Stop if projectile hits ground
            if(point.y < launchPosition.y)
            {
                trajectoryPoints[i] = new Vector3(point.x, launchPosition.y, point.z);
                // Fill remaining points with the same position
                for(int j = i + 1; j < this.trajectoryPoints; j++)
                {
                    trajectoryPoints[j] = trajectoryPoints[i];
                }
                break;
            }
        }
        
        trajectoryLine.SetPositions(trajectoryPoints);
        trajectoryLine.enabled = true;
    }
    
    void UpdateLauncherRotation()
    {
        if(launcher != null)
        {
            launcher.transform.rotation = Quaternion.AngleAxis(launchAngle, Vector3.forward);
        }
    }
    
    public void LaunchProjectile()
    {
        if(isProjectileInMotion) return;
        
        // Hide trajectory preview
        trajectoryLine.enabled = false;
        
        // Reset projectile position
        projectile.transform.position = launchPosition + Vector3.up * 0.1f;
        projectile.SetActive(true);
        
        // Apply initial velocity
        Vector3 initialVelocityVector = launchDirection * initialVelocity;
        projectileRb.velocity = initialVelocityVector;
        
        // Enable trail effect
        if(trailEffect != null)
        {
            trailEffect.Play();
        }
        
        // Start motion tracking
        isProjectileInMotion = true;
        flightTime = 0f;
        
        StartCoroutine(TrackProjectileMotion());
    }
    
    IEnumerator TrackProjectileMotion()
    {
        while(isProjectileInMotion)
        {
            flightTime += Time.deltaTime;
            
            // Apply custom gravity for better control
            Vector3 gravityForce = new Vector3(0, acceleration, 0) * projectileRb.mass;
            projectileRb.AddForce(gravityForce, ForceMode.Force);
            
            // Update kinematics display
            CalculateKinematics();
            
            // Check if projectile hits ground or goes too far
            if(projectile.transform.position.y < launchPosition.y - 0.1f || 
               flightTime > maxTrajectoryTime)
            {
                StopProjectileMotion();
            }
            
            yield return null;
        }
    }
    
    void StopProjectileMotion()
    {
        isProjectileInMotion = false;
        projectileRb.velocity = Vector3.zero;
        projectileRb.angularVelocity = Vector3.zero;
        
        if(trailEffect != null)
        {
            trailEffect.Stop();
        }
        
        // Show final values for a moment before enabling preview again
        StartCoroutine(DelayedTrajectoryPreview());
    }
    
    IEnumerator DelayedTrajectoryPreview()
    {
        yield return new WaitForSeconds(2f);
        ShowTrajectoryPreview();
    }
    
    public void ResetSimulation()
    {
        isProjectileInMotion = false;
        flightTime = 0f;
        
        if(projectileRb != null)
        {
            projectileRb.velocity = Vector3.zero;
            projectileRb.angularVelocity = Vector3.zero;
        }
        
        projectile.transform.position = launchPosition + Vector3.up * 0.1f;
        
        if(trailEffect != null)
        {
            trailEffect.Stop();
        }
        
        CalculateKinematics();
        ShowTrajectoryPreview();
    }
    
    void Update()
    {
        // Keep UI panel facing the camera
        if(uiPanel != null && Camera.main != null)
        {
            Vector3 directionToCamera = Camera.main.transform.position - uiPanel.transform.position;
            uiPanel.transform.rotation = Quaternion.LookRotation(-directionToCamera);
        }
    }
    
    void OnEnable()
    {
        ResetSimulation();
    }
    
    // Method to demonstrate different scenarios
    public void DemonstrateScenario(string scenario)
    {
        switch(scenario.ToLower())
        {
            case "high_angle":
                angleSlider.value = 75f;
                break;
            case "low_angle":
                angleSlider.value = 15f;
                break;
            case "optimal_angle":
                angleSlider.value = 45f;
                break;
            case "high_velocity":
                initialVelocitySlider.value = 25f;
                break;
            case "low_gravity":
                accelerationSlider.value = -5f;
                break;
        }
    }
}
