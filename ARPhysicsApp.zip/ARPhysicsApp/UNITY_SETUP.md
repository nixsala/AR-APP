# 🚀 Unity Setup Guide - AR Physics Explorer

This guide will help you set up and run the AR Physics application in Unity.

## 📋 Prerequisites Checklist

- [ ] **Unity Hub** installed (download from [unity.com/download](https://unity.com/download))
- [ ] **Unity 2021.3 LTS** or later installed via Unity Hub
- [ ] **Android SDK** (for Android builds) or **Xcode** (for iOS builds)
- [ ] **AR-capable mobile device** for testing

## 🚀 Quick Start

### Option 1: Using the Launch Script (Recommended)
1. Open PowerShell as Administrator
2. Navigate to project directory:
   ```powershell
   cd "C:\Users\HP\ARPhysicsApp"
   ```
3. Run the launcher script:
   ```powershell
   .\LaunchUnity.ps1
   ```

### Option 2: Manual Setup
1. Open Unity Hub
2. Click "Add" → Select folder `C:\Users\HP\ARPhysicsApp`
3. Click on the project to open it in Unity

## 🔧 Unity Configuration Steps

### 1. Install AR Foundation Packages
1. Open **Window** → **Package Manager**
2. Change dropdown from "In Project" to "Unity Registry"
3. Search and install these packages:
   - **AR Foundation** (4.2.7 or later)
   - **ARCore XR Plugin** (4.2.7 - for Android)
   - **ARKit XR Plugin** (4.2.7 - for iOS)

### 2. Configure XR Settings
1. Go to **Edit** → **Project Settings**
2. Navigate to **XR Plug-in Management**
3. For **Android**: Check ✅ **ARCore**
4. For **iOS**: Check ✅ **ARKit**

### 3. Open Main Scene
1. In Project window, navigate to `Assets/Scenes/`
2. Double-click **ARPhysicsScene.unity**

### 4. Configure Build Settings

#### For Android:
1. **File** → **Build Settings** → **Android**
2. Click "Switch Platform"
3. **Player Settings** → **Configuration**:
   - Minimum API Level: **24** (Android 7.0)
   - Target API Level: **Automatic (highest installed)**
   - Scripting Backend: **IL2CPP**
   - Target Architectures: **ARM64** ✅

#### For iOS:
1. **File** → **Build Settings** → **iOS**
2. Click "Switch Platform"
3. **Player Settings** → **Configuration**:
   - Target minimum iOS Version: **11.0**
   - Camera Usage Description: "This app uses the camera for AR physics simulations"

## 🎮 Testing in Unity Editor

### Play Mode Testing (Limited AR)
1. Click the **Play** button in Unity
2. You'll see the UI, but full AR features require a mobile device

### Script Testing
1. Check **Console** window for any errors
2. All physics modules should initialize without errors

## 📱 Building and Deploying

### Android Build
1. Connect Android device with **Developer Mode** enabled
2. **File** → **Build Settings** → **Build And Run**
3. Choose save location for APK
4. Unity will build and install on your device

### iOS Build
1. **File** → **Build Settings** → **Build**
2. Choose folder for Xcode project
3. Open generated Xcode project
4. Configure signing and deploy to device

## 🧪 Testing the AR Features

### On Mobile Device:
1. **Launch the app**
2. **Point camera** at a flat, well-lit surface
3. **Wait for plane detection** (white wireframe appears)
4. **Tap a module button** (Ohm's Law, Kinematic, or Force)
5. **Tap on detected plane** to place the physics simulation
6. **Interact** with sliders and controls

## ⚡ Physics Modules Overview

### 1. Ohm's Law Module (V = IR)
- **Controls**: Voltage slider, Resistance slider
- **Visuals**: Glowing wires, electron particles, heating effects
- **Learning**: Real-time V, I, R calculations

### 2. Kinematic Module (v = u + at)
- **Controls**: Velocity, angle, acceleration sliders, Launch button
- **Visuals**: Trajectory preview, particle trails
- **Learning**: Projectile motion with live calculations

### 3. Force Module (F = ma)
- **Controls**: Force slider, mass object selection, Apply Force button
- **Visuals**: Force vectors, acceleration indicators
- **Learning**: Newton's Second Law demonstration

## 🐛 Troubleshooting

### Common Issues:

**"AR Foundation packages not found"**
- Solution: Install packages via Package Manager (Window → Package Manager)

**"Scripts have compile errors"**
- Solution: Check Unity version (2021.3+ required), ensure all scripts are in Assets/Scripts/

**"XR Plug-in Management not available"**
- Solution: Install XR packages first, then access via Edit → Project Settings

**"Build fails on Android"**
- Solution: Check SDK setup, ensure API level 24+, enable ARCore in XR settings

**"AR not working on device"**
- Solution: Ensure device supports ARCore/ARKit, check camera permissions, test on well-lit flat surface

## 📁 Project Structure Reference

```
ARPhysicsApp/
├── Assets/
│   ├── Scenes/
│   │   └── ARPhysicsScene.unity     ← Main scene file
│   ├── Scripts/
│   │   ├── ARPhysicsManager.cs      ← Main AR controller
│   │   ├── OhmsLawModule.cs         ← V=IR physics
│   │   ├── KinematicModule.cs       ← v=u+at physics  
│   │   ├── ForceModule.cs           ← F=ma physics
│   │   └── ARTouchInteractionFixed.cs ← Touch handling
│   ├── Prefabs/                     ← Module prefabs (create these)
│   ├── Materials/                   ← Visual materials
│   └── UI/                          ← Interface prefabs
└── Packages/
    └── manifest.json                ← AR Foundation dependencies
```

## 🎯 Next Steps

1. **Create Prefabs**: Build physics module prefabs with 3D models
2. **Add Materials**: Create materials for visual effects
3. **Test on Device**: Deploy and test all AR interactions
4. **Customize**: Modify physics parameters and visual effects
5. **Extend**: Add more physics principles or educational content

## 📞 Support

- Check **README.md** for comprehensive documentation
- Unity Console for error messages
- Unity Manual: [docs.unity3d.com](https://docs.unity3d.com)
- AR Foundation Documentation: [docs.unity3d.com/Packages/com.unity.xr.arfoundation](https://docs.unity3d.com/Packages/com.unity.xr.arfoundation@4.2/manual/index.html)

---
**Ready to explore physics in AR!** 🔬✨